"use strict";
function asteroids() {
    document.getElementById("Play").setAttribute("disabled", "true");
    const score = document.getElementById("Score");
    const lives = document.getElementById("Lives");
    const svg = document.getElementById("canvas");
    let g = new Elem(svg, 'g')
        .attr("transform", "translate(300 300)")
        .attr("rotation", 0)
        .attr("xVelocity", 0)
        .attr("yVelocity", 0)
        .attr("dead", "false")
        .attr("protection", "false");
    let ship = new Elem(svg, 'polygon', g.elem)
        .attr("points", "-10,15 10,15 0,-15")
        .attr("style", "fill:orange;stroke:white;stroke-width:1");
    const transformMatrix = (e) => new WebKitCSSMatrix(window.getComputedStyle(e.elem).webkitTransform);
    const gameStats = {
        score: 0,
        lives: 3,
    };
    const getRotation = () => Number(g.attr("rotation"));
    const degToRad = (num) => num * (Math.PI / 180);
    const rotationToRad = () => (degToRad(getRotation()));
    const calculateForwardsVelocityX = (num) => (num + 15 * (Math.sin(rotationToRad())));
    const calculateForwardsVelocityY = (num) => (num - 15 * (Math.cos(rotationToRad())));
    const calculateBackwardsVelocityX = (num) => (num - 15 * (Math.sin(rotationToRad())));
    const calculateBackwardsVelocityY = (num) => (num + 15 * (Math.cos(rotationToRad())));
    const bulletVelocityX = () => (5 * (Math.sin(rotationToRad())));
    const bulletVelocityY = () => (5 * (Math.cos(rotationToRad())));
    const gameInterval = Observable.interval(10).map(() => ({ gameStats }));
    const gameEnd = gameInterval.filter(_ => gameStats.lives <= 0)
        .map(() => {
        svg.remove();
        document.write("<body><h1 style='color:black  '>Game Over. Reload To Restart</h1></body>");
    });
    const gameObservable = gameInterval.takeUntil(gameEnd);
    const shipInterval = Observable.interval(0).map(() => ({ g }));
    const shipObservable = shipInterval.takeUntil(gameEnd);
    const updateLives = () => lives.innerHTML = "Lives: " + String(gameStats.lives);
    const updateScore = () => score.innerHTML = "Score: " + String(gameStats.score);
    gameObservable.map(() => updateLives()).subscribe(() => { });
    gameObservable.map(() => updateScore()).subscribe(() => { });
    shipObservable.filter(() => transformMatrix(g).m42 > 620)
        .map(() => g.attr("transform", "translate(" + String(transformMatrix(g).m41) + " " + String(-10) + ")"))
        .subscribe(() => { });
    shipObservable.filter(() => transformMatrix(g).m42 < -20)
        .map(() => g.attr("transform", "translate(" + String(transformMatrix(g).m41) + " " + String(610) + ")"))
        .subscribe(() => { });
    shipObservable.filter(() => transformMatrix(g).m41 < -20)
        .map(() => g.attr("transform", "translate(" + String(610) + " " + String(transformMatrix(g).m42) + ")"))
        .subscribe(() => { });
    shipObservable.filter(() => transformMatrix(g).m41 > 620)
        .map(() => g.attr("transform", "translate(" + String(-10) + " " + String(transformMatrix(g).m42) + ")"))
        .subscribe(() => { });
    shipObservable.flatMap(() => Observable.fromArray(asteroidCollision())
        .filter((asteroid) => Number(asteroid.getAttribute('r')) > calculateDistance(Number(transformMatrix(g).m41), Number(asteroid.getAttribute('cx')), Number(transformMatrix(g).m42), Number(asteroid.getAttribute('cy'))))
        .filter(() => g.attr("protection") == "false")
        .map(() => {
        g.attr("dead", "true")
            .attr("transform", "translate(300 300)rotate(0)")
            .attr("rotation", 0);
    })).subscribe(() => { gameStats.lives -= 1, updateLives(); });
    shipObservable.filter(() => g.attr("dead") == "true")
        .map(() => { g.attr("protection", "true").attr("dead", "false"); })
        .subscribe(() => { });
    shipObservable.filter(() => g.attr("dead") == "true");
    Observable.interval(3000).takeUntil(gameEnd).filter(() => g.attr("dead") == "false")
        .map(() => { g.attr("protection", "false"); }).subscribe(() => { });
    const keydown = Observable.fromEvent(document, 'keydown').takeUntil(gameEnd);
    keydown.filter((input) => input.key == "w")
        .map(() => g.attr("transform", "translate(" + (calculateForwardsVelocityX(transformMatrix(g).m41))
        + " " + (calculateForwardsVelocityY(transformMatrix(g).m42)) + ")rotate(" + getRotation() + ")"))
        .subscribe(() => { });
    keydown.filter((input) => input.key == "s")
        .map(() => g.attr("transform", "translate(" + (calculateBackwardsVelocityX(transformMatrix(g).m41))
        + " " + (calculateBackwardsVelocityY(transformMatrix(g).m42)) + ")rotate(" + getRotation() + ")"))
        .subscribe(() => { });
    keydown.filter((input) => input.key == "d")
        .map(() => g.attr("transform", "translate(" + transformMatrix(g).m41 + " " + transformMatrix(g).m42 + ")rotate(" + (getRotation() + 10) % 360 + ")")
        .attr("rotation", String((Number(g.attr("rotation")) + 10) % 360))).subscribe(() => { });
    keydown.filter((input) => input.key == "a")
        .map(() => g.attr("transform", "translate(" + transformMatrix(g).m41 + " " + transformMatrix(g).m42 + ")rotate(" + (360 + getRotation() - 10) % 360 + ")")
        .attr("rotation", String((360 + Number(g.attr("rotation")) - 10) % 360))).subscribe(() => { });
    const bulletTimer = Observable.interval(2500).takeUntil(gameEnd);
    const removeBulletElem = (elem) => elem.elem.remove();
    const calculateDistance = (x1, x2, y1, y2) => Math.sqrt((Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2)));
    const bullets = keydown.filter((input) => input.key == " ").map(() => ({
        bullet: new Elem(svg, 'circle').attr("cx", String(transformMatrix(g).m41)).attr("cy", String(transformMatrix(g).m42))
            .attr("r", "5").attr("fill", "white").attr("velocityX", String(bulletVelocityX()))
            .attr("velocityY", String(bulletVelocityY()))
    }));
    const asteroidCollision = () => Array.from(document.getElementsByClassName('asteroid'));
    bullets.flatMap(({ bullet }) => Observable.interval(0).takeUntil(bulletTimer).map(() => ({
        bullet: bullet.attr("cx", (Number(bullet.attr("cx")) + Number(bullet.attr("velocityX"))))
            .attr("cy", (Number(bullet.attr("cy")) - Number(bullet.attr("velocityY"))))
    })).flatMap(() => Observable.fromArray(asteroidCollision()))
        .filter((asteroid) => Number(asteroid.getAttribute('r')) > calculateDistance(Number(bullet.attr('cx')), Number(asteroid.getAttribute('cx')), Number(bullet.attr('cy')), Number(asteroid.getAttribute('cy'))))
        .map((asteroid) => {
        asteroid.remove();
        removeBulletElem(bullet);
    })).subscribe(() => { gameStats.score += 50, updateScore(); });
    const asteroidSpawns = ["630", "-30"];
    const getOneOfTwoSpawns = () => asteroidSpawns[Math.floor(Math.random() * 2)];
    const randomAsteroidAngle = () => degToRad((Math.random() * 360));
    const randomAsteroidVelocityX = () => (2 * (Math.sin(randomAsteroidAngle())));
    const randomAsteroidVelocityY = () => (2 * (Math.cos(randomAsteroidAngle())));
    const zeroToSix = () => Math.floor(Math.random() * 600);
    const outOfBounds = (num) => num > 650 || num < -50;
    const outOfBoundNegative = (num) => num < -50;
    const asteroidSpawnTimer = Observable.interval(1000).takeUntil(gameEnd);
    const spawn = asteroidSpawnTimer.map(() => ({
        asteroid: new Elem(svg, 'circle').attr("cx", getOneOfTwoSpawns())
            .attr("cy", String(zeroToSix()))
            .attr("r", "30")
            .attr("fill", "grey")
            .attr("velocityX", String(randomAsteroidVelocityX()))
            .attr("velocityY", String(randomAsteroidVelocityY()))
            .attr("class", "asteroid")
    }));
    spawn.flatMap(({ asteroid }) => Observable.interval(0).takeUntil(gameEnd)
        .map(() => ({
        asteroid: asteroid.attr("cx", Number(asteroid.attr("cx")) + Number(asteroid.attr("velocityX")))
            .attr("cy", Number(asteroid.attr("cy")) + Number(asteroid.attr("velocityY")))
    }))
        .filter(({ asteroid }) => outOfBounds(Number(asteroid.attr("cx"))) || outOfBounds(Number(asteroid.attr("cy")))).
        map(() => outOfBounds(Number(asteroid.attr("cx"))) ? outOfBoundNegative(Number(asteroid.attr("cx"))) ? asteroid.attr("cx", 650) : asteroid.attr("cx", -30)
        : outOfBoundNegative(Number(asteroid.attr("cy"))) ? asteroid.attr("cy", 650) : asteroid.attr("cy", -30)))
        .subscribe(() => { });
}
if (typeof window != 'undefined')
    window.onload = () => {
    };
//# sourceMappingURL=asteroids.js.map