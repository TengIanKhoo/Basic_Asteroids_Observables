/* I Have chosen to recreate the game of asteroids, with movement from the keyboard, as this is more true 
to the classical game in terms of design. I have been able to meet the minimum requirements for the assignment
 I have implemented wrapping of the ship and asteroid around the canvas. My bullets and ship can collide with the
 asteroid and destroy the ship/asteroid. There is a lives and score counter, but the level feature has not been implemented
 I decided to make my bullets and asteroid into circle shapes becasue it was easier to calculate if a collision occured.
The asteroids are made to spawn from the left and right edge of the canvas, but becasue of the wrapping  and
random x and y velocity can also seem like they spawn from the top.
\I have also added a very basic spawn protection for the ship so that it will not contantly get killed, it is however still
a bit buggy.
Also added a  very very basic game over screen
The canvas has been left as is of a size 600x600.
Unless stated otherwise, most of all my functions are impure becasue they cause a change to the input(change the 
  state of an object, for e.g the ship coordinates) or cause an output (e.g shooting of bullets).
  There are a few pure functions inside my code but they are sparse.
  Also most of the functions are lazy, so they can be evaluated only when they are called by the observable
  and be calculate the change in value at any time
*/

function asteroids() {
  // Inside this function you will use the classes and functions 
  // defined in svgelement.ts and observable.ts
  // to add visuals to the svg element in asteroids.html, animate them, and make them interactive.
  // Study and complete the Observable tasks in the week 4 tutorial worksheet first to get ideas.

  // You will be marked on your functional programming style
  // as well as the functionality that you implement.
  // Document your code!  
  // Explain which ideas you have used ideas from the lectures to 
  // create reusable, generic functions.
  
  // here i get the element of the play button and siable it. It works because we only call
  // asteroids() once on the button onlcik attribute
  document.getElementById("Play")!.setAttribute("disabled","true");

  // More HTML document for keeping track of the score and lives
  const score = document.getElementById("Score")!;
  const lives = document.getElementById("Lives")!;
  const svg = document.getElementById("canvas")!;
  // make a group for the spaceship and a transform to move it and rotate it
  // to animate the spaceship you will update the transform property
  let g = new Elem(svg,'g')
    .attr("transform","translate(300 300)")
    .attr("rotation",0)
    .attr("xVelocity",0)
    .attr("yVelocity",0)
    .attr("dead","false")
    .attr("protection","false")
  
  // create a polygon shape for the space ship as a child of the transform group
  let ship = new Elem(svg, 'polygon', g.elem) 
    .attr("points","-10,15 10,15 0,-15")
    .attr("style","fill:orange;stroke:white;stroke-width:1")

  // Function that gets the current transform property of the given Elem
  // I did not use g.elem.getboundingClientRect() because that changes the x,y after rotation
  const transformMatrix = 
    (e:Elem) => new WebKitCSSMatrix(window.getComputedStyle(e.elem).webkitTransform)

  // this is an object that contains all current relevant stats that the player might be interested in
  const gameStats = {
    score: 0,
    lives: 3,
  }

  //  Each of these functions is a pure function, becasue they do not change the input in any way
  // or cause an output
  // Gets the current rotation of the ship
  const getRotation  = () => Number(g.attr("rotation"))
  // converts an angle given in degrees to radians
  const degToRad = (num:number):number => num * (Math.PI/180)
  // converts the rotation of the ship into radians
  const rotationToRad = () :number => (degToRad(getRotation()))
  // function used to calculate the velocity of X, based on the ships angle, used to move forwards
  const calculateForwardsVelocityX = (num:number) : number =>  (num + 15 *(Math.sin(rotationToRad())))
  // function used to calculate the velocity of Y, based on the ships angle, used to move forwards
  const calculateForwardsVelocityY = (num:number) : number =>  (num - 15 *(Math.cos(rotationToRad())))
  // function used to calculate the velocity of X, based on the ships angle, used to move backwards
  const calculateBackwardsVelocityX = (num:number) : number =>  (num - 15 *(Math.sin(rotationToRad())))
  // function used to calculate the velocity of Y, based on the ships angle, used to move backwards
  const calculateBackwardsVelocityY = (num:number) : number =>  (num + 15 *(Math.cos(rotationToRad())))
  // USed to calculate the velocity of the bullet based on the rotation of the ship
  const bulletVelocityX = () =>  (5*(Math.sin(rotationToRad())))
  const bulletVelocityY = () =>  (5*(Math.cos(rotationToRad())))

  // inspiration taken from https://github.com/harsilspatel/pong-breakout/blob/master/src/pong.ts

  // This is a clock that ticks for the game
  const gameInterval = Observable.interval(10).map(() => ({gameStats}));
  // this is an observable that only exists for 100 ms, but will  fire once to signify the end of the game.
  //Most other observables will takeUntil this observable so they stop once the game ends
  const gameEnd = gameInterval.filter(_ => gameStats.lives <= 0)
  .map(() => {svg.remove();
  document.write("<body><h1 style='color:black  '>Game Over. Reload To Restart</h1></body>")}
  )

  // This is the observable that is responsible for handling the updating of the lives and score
  const gameObservable = gameInterval.takeUntil(gameEnd);
  
  //This is an observable that watches the ship, we use it for the wrapping of the ship around the map
  const shipInterval = Observable.interval(0).map(() => ({g}));
  const shipObservable = shipInterval.takeUntil(gameEnd);

  // impure functions that cause an update to our HTML element
  const updateLives = () => lives.innerHTML = "Lives: " + String(gameStats.lives);
  const updateScore = () => score.innerHTML = "Score: " + String(gameStats.score);
  // mapping of the above functions
  gameObservable.map(() => updateLives()).subscribe(() => {})
  gameObservable.map(() => updateScore()).subscribe(() => {})

  // the following observables check weather or not the ship is out of bounds and needs to be wrapped back to the screen
  // check if ship crosses bottom edge
  shipObservable.filter(() => transformMatrix(g).m42 > 620)
  .map(() => g.attr("transform","translate("+ String(transformMatrix(g).m41) + " " + String(-10) + ")"))
  .subscribe(() => {})
  // if crosses top edge
  shipObservable.filter(() => transformMatrix(g).m42 < -20)
  .map(() => g.attr("transform","translate("+ String(transformMatrix(g).m41) + " " + String(610) + ")"))
  .subscribe(() => {})
  // if crosses left egde
  shipObservable.filter(() => transformMatrix(g).m41 < -20)
  .map(() => g.attr("transform","translate("+ String(610) + " " + String(transformMatrix(g).m42) + ")"))
  .subscribe(() => {})
  // if crosses right edge
  shipObservable.filter(() => transformMatrix(g).m41 > 620)
  .map(() => g.attr("transform","translate("+ String(-10) + " " + String(transformMatrix(g).m42) + ")"))
  .subscribe(() => {})

  //Checking for collision
  shipObservable.flatMap(() => Observable.fromArray(asteroidCollision())
  .filter((asteroid) => Number(asteroid.getAttribute('r')) > calculateDistance(Number(transformMatrix(g).m41), Number(asteroid.getAttribute('cx')), 
  Number(transformMatrix(g).m42), Number(asteroid.getAttribute('cy'))))
  //checking to make sure the ship was not just killed( and so cant be killed again)
  .filter(() => g.attr("protection") == "false")
   .map(() => {
    g.attr("dead","true")
    .attr("transform","translate(300 300)rotate(0)")
    .attr("rotation",0)}
   )
 ).subscribe(() => {gameStats.lives -= 1, updateLives()})

 // implementation of a spwan protection for my ship so that it cant constantly be killed
 shipObservable.filter(() => g.attr("dead") == "true" )
 .map(() => {g.attr("protection","true").attr("dead","false")}
 )
 .subscribe(() => {})
// removing of the spaawn protection, not always conistent becasue it does not check starting from when the ship is killed
 shipObservable.filter(() => g.attr("dead") == "true" )
 Observable.interval(3000).takeUntil(gameEnd).filter(() => g.attr("dead") == "false" )
 .map(() => {g.attr("protection","false")}
 ).subscribe(() => {})

  // Observable that looks at all keypresses of the keyboard
  const keydown = Observable.fromEvent<KeyboardEvent>(document,'keydown').takeUntil(gameEnd)

  //Movement for the ship in a forward direction, based on the current rotation of the ship, casues an update in the
  // transform translate attr of the g
  keydown.filter((input) => input.key == "w")
  .map(() => g.attr("transform","translate("+(calculateForwardsVelocityX(transformMatrix(g).m41))
  + " " +(calculateForwardsVelocityY(transformMatrix(g).m42)) +")rotate("+getRotation()+")"))
  .subscribe(() => {});

  //Backwards movement of the ship, based on the current rotation of the ship casues an update in the
  // transform translate attr of the g
  keydown.filter((input) => input.key == "s")
  .map(() => g.attr("transform","translate("+(calculateBackwardsVelocityX(transformMatrix(g).m41))
  + " " +(calculateBackwardsVelocityY(transformMatrix(g).m42)) +")rotate("+getRotation()+")"))
  .subscribe(() => {});

  //Rotation of the ship 10 degrees to the right, chosen because 5 is more precise but too slow, 15 is too inprecise
  keydown.filter((input) => input.key == "d")
  .map(() => 
    g.attr("transform","translate("+transformMatrix(g).m41+" "+transformMatrix(g).m42+")rotate("+(getRotation() + 10)%360+")")
    .attr("rotation",String((Number(g.attr("rotation")) + 10)%360))).subscribe(() => {});

  //Rotation of the ship 10 degrees to the left, a bit more complex camapred to d, chosen because 5 is more precise but too slow, 15 is too inprecise
  keydown.filter((input) => input.key == "a")
  .map(() => 
    g.attr("transform","translate("+transformMatrix(g).m41+" "+transformMatrix(g).m42+")rotate("+(360 + getRotation() - 10)%360+")")
    .attr("rotation",String((360 + Number(g.attr("rotation")) - 10)%360))).subscribe(() => {});

  // This is a observable that deletes the bullet of the elem after a set amount of time/distance, will also delete the
  // observable related to that bullet
  const bulletTimer = Observable.interval(2500).takeUntil(gameEnd)
  const removeBulletElem =  (elem : Elem) => elem.elem.remove()
  //  thsi si a function that is used to calculate the distance between two points
  const calculateDistance = (x1:number,x2:number,y1:number,y2:number) => Math.sqrt((Math.pow((x1 -x2),2) + Math.pow((y1-y2),2)))

  // observable which when detecting a spacebar, creates bullets
  const bullets = 
  keydown.filter((input) => input.key == " ").map(() => ({
  bullet:
  new Elem(svg,'circle').attr("cx",String(transformMatrix(g).m41)).attr("cy",String(transformMatrix(g).m42))
  .attr("r","5").attr("fill","white").attr("velocityX",String(bulletVelocityX()))
  .attr("velocityY",String(bulletVelocityY()))
  }))

  // lazy function that returns to me an array of asteroid elements in my svg
  const asteroidCollision = () => Array.from(document.getElementsByClassName('asteroid'))

  // Here we create an observable to move our bullet, once again based on the rotation of the ship
  // we also take the observable until bulletTimer, which is the same time we delete the bullet
  
  bullets.flatMap(({bullet}) => Observable.interval(0).takeUntil(bulletTimer).map(() => ({
    bullet:
   bullet.attr("cx", (Number(bullet.attr("cx"))+Number(bullet.attr("velocityX"))))
   .attr("cy",(Number(bullet.attr("cy"))- Number(bullet.attr("velocityY"))))})
   // after we spawned the bullets, we need to check if they collide with any atseroids, there are still major bugs with this
   // help was given to me for this
   ).flatMap(() => Observable.fromArray(asteroidCollision()))
   .filter((asteroid) => Number(asteroid.getAttribute('r')) > calculateDistance(Number(bullet.attr('cx')), Number(asteroid.getAttribute('cx')), Number(bullet.attr('cy')), Number(asteroid.getAttribute('cy'))))
    .map((asteroid) => {
    asteroid.remove()
    removeBulletElem(bullet)}
    )
  ).subscribe(() => {gameStats.score += 50, updateScore()})
  

  // I want the asteroids to spawn from only the left and right edges
  const asteroidSpawns = ["630","-30"];
  // lazy function which will randomly chose one of the available x values to spawn my asteroid from
  const getOneOfTwoSpawns = ():string => asteroidSpawns[Math.floor(Math.random()*2)]
  // lazy function that calculates a random angle for which is used to calculate the x and y value of the asteroid
  const randomAsteroidAngle = ():number => degToRad((Math.random() * 360))
  // lazy function, calculates a random x velocity for the asteroid
  const randomAsteroidVelocityX = ():number => (2*(Math.sin(randomAsteroidAngle()))) 
  // lazy function calculates the random y velocity of the asteroid
  const randomAsteroidVelocityY = ():number => (2*(Math.cos(randomAsteroidAngle()))) 
  // creates a random number from 0 - 600, for is the y axis to spawn my asteroid
  const zeroToSix  = () :number => Math.floor(Math.random() * 600)
  // pure functions that calculate weather or not something is out of bounds
  const outOfBounds = (num:number):boolean => num>650 || num <-50
  const outOfBoundNegative = (num:number):boolean => num < -50
  
  //Spawning of asteroids
  // timer of how often to make my asteroid
  const asteroidSpawnTimer = Observable.interval(2000).takeUntil(gameEnd);
  // the spawning of my asteroid with its random x,y coordinate and random speed
  const spawn = 
  asteroidSpawnTimer.map(() => ({
  asteroid:
  new Elem(svg,'circle').attr("cx",getOneOfTwoSpawns())
  .attr("cy",String(zeroToSix()))
  .attr("r","30")
  .attr("fill","grey")
  .attr("velocityX",String(randomAsteroidVelocityX()))
  .attr("velocityY",String(randomAsteroidVelocityY()))
  .attr("class","asteroid")
  }))
  
  //updating of the my asteroids
  spawn.flatMap(({asteroid}) => Observable.interval(0).takeUntil(gameEnd)
  .map(() => ({
   asteroid: asteroid.attr("cx", Number(asteroid.attr("cx")) + Number(asteroid.attr("velocityX")))
  .attr("cy", Number(asteroid.attr("cy")) + Number(asteroid.attr("velocityY")))}))
  // checking if my asteroids are out of bounds and wrappping them around the screen
  .filter(({asteroid}) => outOfBounds(Number(asteroid.attr("cx"))) || outOfBounds(Number(asteroid.attr("cy")))).
  map(() => outOfBounds(Number(asteroid.attr("cx"))) ? outOfBoundNegative(Number(asteroid.attr("cx"))) ? asteroid.attr("cx",650) : asteroid.attr("cx",-30)
  : outOfBoundNegative(Number(asteroid.attr("cy"))) ? asteroid.attr("cy",650) : asteroid.attr("cy",-30)))
  .subscribe(() => {})

}
// the following simply runs your asteroids function on window load.  Make sure to leave it in place.
if (typeof window != 'undefined')
  window.onload = ()=>{
    //asteroids();
  }